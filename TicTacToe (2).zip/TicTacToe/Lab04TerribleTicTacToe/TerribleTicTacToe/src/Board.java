public class Board{
	
	private int size;
	private char [][] board;
	
	
	
	public Board(int _size){
		size=_size;
		//System.out.println(size);
		board=new char [size][size];
		for(int x = 0; x < size; x++)
					for(int y = 0; y < size; y++) {
						board[x][y] = ' ';
		}
		
	}
	
	
	public void updateBoard(int r, int c, char ch)  {
	
			board[r][c]=ch;
	}
	
	
	public char[][] getBoard(){
		return board;
	}
	
	
	public boolean ifBoardPositionIsFree(int r, int c) {
	
	

		if(board[r][c]==' ') {
			return true;
		}else
			return false;
		} 
	
}
public class Controller {
    private View firstView;
	private View SecondView;
	private RuleEngine ruleEngine;
	private Player playerOne;
	private Player playerTwo;
	public  Board board;
	private int sizeOfBoard; 
	private Player player;
	
    public Controller(){

		firstView= new View(this);
		SecondView=new View(this);
		ruleEngine=new RuleEngine(this,sizeOfBoard);
		playerOne=new Player('O');
		playerTwo=new Player('X');
		
	}

    public Board getBoard(){
		return board;
	}
	
		
	public void unitClicked(int _row, int _column) {
		String str;
		if(ruleEngine.isValidMove(_row, _column)&& ruleEngine.isPlayer1sTurn()&& ruleEngine.gameIsWon==false){
			
			ruleEngine.updateBoard(_row,_column, playerOne.getTile());
			board.updateBoard(_row, _column, playerOne.getTile());
			ruleEngine.takeTurn(playerOne.getTile());
			firstView.updatePlayerTurn("player 2's turn");
			//----
			SecondView.updatePlayerTurn("player 2's turn");
			SecondView.updateView(_row,_column,str=Character.toString(playerOne.getTile()));
			//----
			firstView.updateView(_row, _column,str=Character.toString(playerOne.getTile()));
			if(ruleEngine.isGameWon(_row, _column, playerOne.getTile())){
				firstView.myLabel.setText("player 1 won!");
				//---
				SecondView.myLabel.setText("player 1won! ");
			}
			
		}else if(ruleEngine.isValidMove(_row, _column)&& !ruleEngine.isPlayer1sTurn()&&ruleEngine.gameIsWon==false){
			ruleEngine.updateBoard(_row,_column, playerTwo.getTile());
			board.updateBoard(_row, _column, playerTwo.getTile());
			ruleEngine.playerOnesTurn=true;
			
			//-----
			SecondView.updatePlayerTurn("player 1's turn");
			SecondView.updateView(_row,_column,str=Character.toString(playerTwo.getTile()));
			//---
			firstView.updatePlayerTurn("player 1's turn");
			firstView.updateView(_row, _column,str=Character.toString(playerTwo.getTile()));
			if(ruleEngine.isGameWon(_row, _column, playerTwo.getTile())){
				//---
				SecondView.myLabel.setText("player 2 won!");
				firstView.myLabel.setText("player 2 won!");
			}
		}
    }
	

        public void setBoardSize(int x){
            sizeOfBoard=x;
            board=new Board(sizeOfBoard);
        }
        
        
        
        public int getBoardSize(){
            return sizeOfBoard;
        
        }
}

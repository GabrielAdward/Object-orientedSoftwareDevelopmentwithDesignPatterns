
public class Launcher {
	
    Controller controller;
    public static void main(String[]args) {
        Controller controller= new Controller();
        
    }
    
}
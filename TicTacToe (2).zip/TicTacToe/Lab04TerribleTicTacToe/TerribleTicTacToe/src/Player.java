public class Player{
	private char tile;

	
	public Player(char ch) {
		tile=ch;
	
		
		
	}
	
	public char getTile() {
		return tile;
	}
	
	
}
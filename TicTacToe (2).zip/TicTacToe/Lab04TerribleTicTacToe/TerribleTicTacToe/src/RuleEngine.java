
public class RuleEngine {
	private Controller controller;   
	private int boardSize;
	public boolean playerOnesTurn;
	public boolean gameIsWon;
	
	
public RuleEngine(Controller _controller, int _boardSize){
	
	controller=_controller;
	boardSize=_boardSize;
	playerOnesTurn=true;
	gameIsWon=false;
}


public boolean isPlayer1sTurn(){
	
	return playerOnesTurn;
}

public void takeTurn(char ch) {
	if(ch=='O')
	playerOnesTurn=false;
	else
	playerOnesTurn=true;
	
}

public boolean isValidMove(int row, int col) {
   return controller.board.ifBoardPositionIsFree(row, col);
}

public void updateBoard(int r, int c, char ch){
	controller.board.updateBoard(r,c,ch);
}

public boolean isGameWon(int r, int c,char ch){
	char [][] board=controller.board.getBoard();
	boardSize=controller.getBoardSize();
	
	//Checks vertical
	
	if(r-1>=0 && board[r-1][c]==ch && r-2>=0 && board[r-2][c]==ch) {
			gameIsWon=true;
			return true;
		}
	
	//Checks vertical	
	if(r+1<boardSize && board[r+1][c]==ch && r+2<boardSize && board[r+2][c]==ch){
			gameIsWon=true;
			return true;
		}
	
	//Checks Horizontal
	if(c+1<boardSize &&board[r][c+1]==ch && c+2 <boardSize && board[r][c+2]==ch){
			gameIsWon=true;
			return true;
		}
	
	//Checks Horizontal	
	if( c-1>=0 && board[r][c-1]==ch && c-2>=0 && board[r][c-2]==ch){
			gameIsWon=true;
			return true;	
		}
	
	//checking diagonals X 4
		
	if(r+1<boardSize && c-1>=0 && board[r+1][c-1]==ch && r+2<boardSize && c-2>=0 && board[r+2][c-2] ==ch){
			gameIsWon=true;
			return true;
	}
	
	//checking diagonals	
	if(r+1<boardSize && c+1<boardSize &&board[r+1][c+1]==ch && r+2<boardSize && c+2 <boardSize && board[r+2][c+2]==ch && r+3<boardSize && c+3<boardSize && board[r+3][c+3]==ch){
			gameIsWon=true;
			return true;
	}
	
	if(r-1>=0 && c-1>=0 && board[r-1][c-1]==ch && r-2>=0 && c-2>=0 && board[r-2][c-2]==ch) {
			gameIsWon=true;
			return true;
	}
				
	
	if(r-1>=0 && c+1<boardSize && board[r-1][c+1]==ch && r-2 >=0 && c+2<boardSize && board[r-2][c+2]==ch){
			gameIsWon=true;
			return true;
	}
	
	//handles if you put the winning marker in the middle

	
	if(r-1>=0 && board[r-1][c]==ch && r+1<boardSize && board[r+1][c]==ch) {
		gameIsWon=true;
		return true;
	}
		
	if(c-1>=0 && board[r][c-1]==ch && c+1<boardSize && board[r][c+1]==ch) {
		gameIsWon=true;
		return true;
	}
		
	if(r-1>=0 && c-1>=0 && board[r-1][c-1]==ch && r+1<boardSize && c+1<boardSize && board[r+1][c+1]==ch) {
		gameIsWon=true;
		return true;
	}
		
	
	if(r-1>=0 && c+1<boardSize && board[r-1][c+1]==ch && r+1<boardSize && c-1>=0 &&board[r+1][c-1]==ch) {
		gameIsWon=true;
		return true;
	}
		
	
	else
		return false;


}



}
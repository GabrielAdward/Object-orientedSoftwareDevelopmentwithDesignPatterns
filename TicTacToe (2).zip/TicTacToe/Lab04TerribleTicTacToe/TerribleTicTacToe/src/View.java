import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.*;

import javax.swing.*;

public class View extends JFrame{
	private Controller controller;

	private JButton button;
	private JPanel myButtonPanel;
	private JPanel mainPanel;
	private JFrame frame;
	private JPanel myTextPanel; 
	private JMenuBar menuBar;
	private JButton buttons [][];
	public JLabel myLabel;
	JMenu sizeMenu;
	JMenu numberOfPlayers;
	JMenuItem size3x3;
	JMenuItem size9x9;
	JMenuItem twoPlayers;
	JMenuItem onePlayer;
	

public View(Controller _controller) {
	
	controller=_controller;
	
	frame=new JFrame();
	mainPanel=new JPanel();
	menuBar=new JMenuBar();
	sizeMenu= new JMenu("Size");
	numberOfPlayers=new JMenu("Number of Players");
	
	size3x3=new JMenuItem("3x3");
	size9x9=new JMenuItem("9x9");
	twoPlayers=new JMenuItem("Two players");
	onePlayer=new JMenuItem("Single player");
	
	numberOfPlayers.add(onePlayer);
	numberOfPlayers.add(twoPlayers);
	sizeMenu.add(size3x3);
	sizeMenu.add(size9x9);
	menuBar.add(sizeMenu);
	menuBar.add(numberOfPlayers);
	frame.setJMenuBar(menuBar);
	myButtonPanel= new JPanel();
	
	myTextPanel = new JPanel();
    myTextPanel.setLayout(new GridLayout(1,1));
    myLabel = new JLabel("player 1's turn", SwingConstants.CENTER);
    myTextPanel.setPreferredSize(new Dimension(150,50));
    myTextPanel.add(myLabel);
    mainPanel.add(myTextPanel);
	
	size3x3.addActionListener(new ActionListener() {
		
		
		public void actionPerformed(ActionEvent e) {
			controller.setBoardSize(3);
			frame.setSize(400,660);
			buttons= new JButton[controller.getBoardSize()][controller.getBoardSize()];
			myButtonPanel.setLayout(new GridLayout(controller.getBoardSize(),controller.getBoardSize()));
	        
			for(int r = 0; r < controller.getBoardSize(); r++) {
		    	for(int c = 0; c <controller.getBoardSize(); c++) {
		    	final int _row = r;
		    	final int _column = c;
		    	button = buttons[r][c] = new JButton();
		    	button.setPreferredSize(new Dimension(100, 100));
		    	button.addActionListener(new ActionListener() {
			    	@Override
			    	public void actionPerformed(ActionEvent e) {
			    		controller.unitClicked(_row, _column);
			    	}
		    	});
		    	myButtonPanel.add(button);
		    	}
		    }
		mainPanel.add(myButtonPanel);
		mainPanel.add(myTextPanel);
		}
	});
	
	twoPlayers.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		}
	});
	size9x9.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			controller.setBoardSize(9);
			frame.setSize(600,600);
			buttons= new JButton[controller.getBoardSize()][controller.getBoardSize()];
			myButtonPanel.setLayout(new GridLayout(controller.getBoardSize(),controller.getBoardSize()));
	        
			for(int r = 0; r < controller.getBoardSize(); r++) {
		    	for(int c = 0; c <controller.getBoardSize(); c++) {
		    	final int _row = r;
		    	final int _column = c;
		    	button = buttons[r][c] = new JButton();
		    	button.setPreferredSize(new Dimension(50, 50));
		    	button.addActionListener(new ActionListener() {
			    	@Override
			    	public void actionPerformed(ActionEvent e) {
			    		controller.unitClicked(_row, _column);
			    	}
		    	});
		    	myButtonPanel.add(button);
		    	}
		    }
		mainPanel.add(myButtonPanel);
		mainPanel.add(myTextPanel);
		}
			

	});
	

	mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setTitle("Tic Tac Toe");
	frame.setSize(330,330);
	
	frame.getContentPane().add(mainPanel);
	frame.setVisible(true);
   
}
	
public void updateView(int r, int c, String str) {
	this.buttons[r][c].setText(str); 
	
}

public void updatePlayerTurn(String str) {
	this.myLabel.setText(str);
}

}








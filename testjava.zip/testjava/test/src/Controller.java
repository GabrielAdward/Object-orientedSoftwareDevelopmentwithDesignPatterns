import javax.swing.JOptionPane;

// This is a dummy Controller, so the View compiles
public class Controller {

    private View v;
    private EncryptionEngine e;

    public Controller() {
        this.v = new View(this);
        this.e = new EncryptionEngine(this);

    }

    public void encryptButtonClicked(){
        if(checkIfNumberIsValid(v.getEncryptionKey()) && checkIfStringIsValid(v.getInputText())){
            e.setEncryptionKey(Integer.parseInt(v.getEncryptionKey()));
            v.setOutputText(e.encrypt(v.getInputText()));


        }
        else if(!checkIfNumberIsValid( v.getEncryptionKey()) && checkIfStringIsValid(v.getInputText())){
            JOptionPane.showMessageDialog (null, "Only Numbers", "Title", JOptionPane.ERROR_MESSAGE);

        }
       else{
        JOptionPane.showMessageDialog(null, "Capital Letters Only!", "Title", JOptionPane.ERROR_MESSAGE);
       }

        
    }

    public void decryptButtonClicked() {
        if(checkIfNumberIsValid(v.getEncryptionKey()) && checkIfStringIsValid(v.getInputText())){
            e.setEncryptionKey(Integer.parseInt(v.getEncryptionKey()));
            v.setOutputText(e.decrypt(v.getInputText()));
        }
        else if(!checkIfNumberIsValid(v.getEncryptionKey())){
    		JOptionPane.showMessageDialog (null, "Only Numbers", "Title", JOptionPane.ERROR_MESSAGE);
    	}
    	else {
    		JOptionPane.showMessageDialog (null, "Capital Letters Only!", "Title", JOptionPane.ERROR_MESSAGE);
    	}


}


    public boolean checkIfNumberIsValid(String str){
       
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) { return false; } 
    }

    public boolean checkIfStringIsValid(String inputText) {
        char[] input = inputText.toCharArray();
        for (int i = 0; i < inputText.length(); i++) {
            if (input[i] < 65 || input[i] > 90) {
                return false;
            }
        }

        return true;
    }
}

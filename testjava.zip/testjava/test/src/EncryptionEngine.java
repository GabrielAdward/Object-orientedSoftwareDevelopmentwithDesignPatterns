import java.security.Key;

import javax.swing.InputVerifier;

public class EncryptionEngine {

    private Controller c;
    private int encryptionKey;


    public  EncryptionEngine(Controller controll){
        this.c = controll;
    }

    void setEncryptionKey(int key){
        this.encryptionKey = key;
    }

    int getEncryptionKey(){
        System.out.println(encryptionKey);
        return this.encryptionKey;

    }

    public String encrypt(String inputText){
        String result = "";
		int key = this.encryptionKey;
		for(int i=0;i<inputText.length();i++) {
			char ch = (char)(((int)inputText.charAt(i) + key - 65) % 26 + 65);
			result += ch;
		}
		return result;
    }

    public String decrypt(String inputText){
        String result = "";
		int key = this.encryptionKey;
		for(int i=0;i<inputText.length();i++) {
			char ch = (char)(((int)inputText.charAt(i) - key + 65) % 26 + 65);
			result += ch;
		}
		return result;
    }
}

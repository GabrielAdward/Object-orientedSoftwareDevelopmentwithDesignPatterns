import org.junit.Test;
import static org.junit.Assert.assertEquals;


public class EncryptionEngineTest2 {


    @Test
    public void testEncrypt() {
        // Arrange / set-up
        Controller controller = null; // dummy controller
        EncryptionEngine e = new EncryptionEngine(controller);
        e.setEncryptionKey(3); // String or int, depending on your implementation
        // Act and Assert in one line
        assertEquals(e.encrypt("ABC"), "DEF");
        // Another Act and Assert
        assertEquals(e.encrypt("XYZ"), "ABC");
        }
    

    @Test
    public void testDecrypt(){
         // Arrange / set-up
         Controller controller = null; // dummy controller
         EncryptionEngine e = new EncryptionEngine(controller);
         e.setEncryptionKey(3); // String or int, depending on your implementation
         // Act and Assert in one line
         assertEquals(e.decrypt("ABC"), "XYZ");
         // Another Act and Assert
         assertEquals(e.decrypt("DEF"), "ABC");
         }
    }




